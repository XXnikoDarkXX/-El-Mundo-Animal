package com.nicolasfernandez.elmundoanimal.actividades

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.nicolasfernandez.elmundoanimal.R

/**
 * Actividad para informar sobre la ayuda de la aplicacion
 */
class ActividadAyuda : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {




        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actividad_ayuda)




    }
}