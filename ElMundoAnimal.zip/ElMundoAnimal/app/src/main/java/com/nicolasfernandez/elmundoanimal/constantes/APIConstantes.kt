package com.nicolasfernandez.elmundoanimal.constantes

/**
 * Clase donde tendremos variables estaticas implementando un singlenton
 */
class APIConstantes {
    companion object{
        val APIYoutube:String="AIzaSyBuj-rdXbj_3mXcGSOq8BeENbpvgC2vgnw" //Api de youtube configurada
        var userAdmin:Boolean=false//si es admin
    }
}